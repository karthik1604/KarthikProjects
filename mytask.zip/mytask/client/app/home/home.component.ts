import {Component} from '@angular/core';
import {Router} from '@angular/router';

@Component({
   moduleId: module.id,
    selector:'home',
    //template : '<h1>Hello</h1>'
    templateUrl :'home.component.html'
})
export class HomeComponent{


}